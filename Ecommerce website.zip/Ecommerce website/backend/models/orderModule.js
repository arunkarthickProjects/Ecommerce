const mongoose = require('mongoose')

const orderSchema = mongoose.Schema({
        cartItems:Array,
        amount:String,
        status:String,
        createAt: Date
})

const orderModel = mongoose.model('ord',orderSchema)

module.exports = orderModel